﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_Denilse
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btDividir_Click(object sender, EventArgs e)
        {
            lbResultado.Text = (float.Parse(txtNro1.Text) / float.Parse(txtnum2.Text)).ToString();
        }

        private void btSomar_Click(object sender, EventArgs e)
        {
            lbResultado.Text = (float.Parse(txtNro1.Text) + float.Parse(txtnum2.Text)).ToString();
        }

        private void btSubtrair_Click(object sender, EventArgs e)
        {
            lbResultado.Text = (float.Parse(txtNro1.Text) - float.Parse(txtnum2.Text)).ToString();
        }

        private void btMultiplicar_Click(object sender, EventArgs e)
        {
            lbResultado.Text = (float.Parse(txtNro1.Text) * float.Parse(txtnum2.Text)).ToString();
        }
    }
}
